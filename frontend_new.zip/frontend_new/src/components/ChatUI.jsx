import React, { useState } from "react";
import { Send, Upload, Loader2, Trash2 } from "lucide-react";

export default function ChatUI() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [userId, setUserId] = useState(localStorage.getItem("userId") || null);
  const [loading, setLoading] = useState(false);

  const API_URL =
    window.location.hostname === "127.0.0.1" || window.location.hostname === "localhost"
      ? "http://127.0.0.1:8000"
      : window.location.origin;

  const handleSend = async () => {
    if (!message.trim() || !userId) return;
    const msg = { sender: "user", text: message };
    setMessages((prev) => [...prev, msg]);
    setMessage("");
    setLoading(true);

    const resp = await fetch(`${API_URL}/chat/${userId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await resp.json();

    setMessages((prev) => [...prev, { sender: "bot", text: data.answer || "⚠️ Sorry, something went wrong." }]);
    setLoading(false);
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    if (userId) formData.append("user_id", userId);
    formData.append("file", file);
    formData.append("reset_chat", "true");

    setLoading(true);
    const resp = await fetch(`${API_URL}/upload_resume/`, { method: "POST", body: formData });
    const data = await resp.json();
    setLoading(false);

    if (data.user_id) {
      setUserId(data.user_id);
      localStorage.setItem("userId", data.user_id);
      setMessages([{ sender: "bot", text: "✅ Resume uploaded successfully! You can start chatting now." }]);
    } else {
      setMessages([{ sender: "bot", text: "❌ Failed to process resume." }]);
    }
  };

  const handleClearChat = () => {
    setMessages([]);
    localStorage.removeItem("chatHistory");
  };

  return (
    <div className="flex flex-col h-screen max-w-3xl mx-auto bg-white shadow-lg rounded-xl overflow-hidden">
      {/* Header */}
      <header className="flex justify-between items-center bg-blue-600 text-white p-4">
        <h1 className="font-semibold text-lg">🤖 AI Career Coach</h1>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer bg-white text-blue-600 px-3 py-1.5 rounded-md hover:bg-blue-50 transition">
            <Upload size={18} />
            <span>Upload / Re-upload</span>
            <input type="file" hidden onChange={handleUpload} />
          </label>
          <button
            onClick={handleClearChat}
            className="p-2 hover:bg-blue-500 rounded-md transition"
            title="Clear Chat"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </header>

      {/* Chat Container */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-xs md:max-w-md p-3 rounded-2xl ${
                msg.sender === "user"
                  ? "bg-blue-600 text-white rounded-br-none"
                  : "bg-gray-200 text-gray-900 rounded-bl-none"
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-center text-gray-400">
            <Loader2 className="animate-spin" size={20} />
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="flex items-center gap-3 p-4 border-t bg-white">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask about your career, skills, or salary..."
          className="flex-1 border border-gray-300 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={handleSend}
          disabled={loading}
          className="bg-blue-600 text-white rounded-full p-2 hover:bg-blue-700 transition"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
}